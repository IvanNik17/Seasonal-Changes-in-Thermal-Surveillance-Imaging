# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 10:33:16 2021

@author: Ivan
"""

import cv2
import os
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

import seaborn as sns

def plot_error_vs_datetime(df):
    #ax = sns.scatterplot(data=df, x="Date", y="MSE", hue="Time")
    ax = sns.lineplot(data=df, x="DateTime", y="MSE", hue="model")

    ax.xaxis.set_major_locator(ticker.MultipleLocator(15))
    plt.xticks(rotation=45)
    #plt.legend(loc='upper right')
    #plt.show()
    plt.savefig('drift_plot.png')

if __name__ == '__main__':
    models = ['feb_day', 'feb_week', 'feb_month'][:]
    months = ['results_jan', 'results_apr', 'results_aug'][:]

    df = None
    for model in models:
        print(model)
        for month in months:
            print(month)
            path = os.path.join(model,month+'.csv')

            df_ = pd.read_csv(path)

            print("mean {:.5f}, std {:.5f}".format(df_['MSE'].mean(),df_['MSE'].std()))

            df_["Date"] = pd.to_datetime(df_['DateTime'], dayfirst = True).dt.strftime('%m-%d')
            df_["Time"] = pd.to_datetime(df_['DateTime']).dt.hour


            df_['model'] = model
            df_['month'] = month

            if df is None:
                df = df_
            else:
                df = df.append(df_)

    plot_error_vs_datetime(df)
