# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 10:33:16 2021

@author: Ivan
"""

import cv2
import os
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

import seaborn as sns

def plot_error_vs_datetime(df):
    #sns.scatterplot(data=df, x="DateTime", y="MSE", hue="model")
    ax = sns.lineplot(data=df, x="DateTime", y="MSE", hue="model")

    ax.xaxis.set_major_locator(ticker.MultipleLocator(15))
    plt.xticks(rotation=45)

    #plt.show()
    plt.savefig('drift_plot.png')

if __name__ == '__main__':
    models = ['feb_day', 'feb_week', 'feb_month']
    months = ['results_jan_month', 'results_apr_month', 'results_aug_month']

    df = None
    for model in models:

        for month in months:
            path = os.path.join(model,month+'.csv')

            df_ = pd.read_csv(path)
            df_["DateTime"] = pd.to_datetime(df_['DateTime'], dayfirst = True).dt.strftime('%m-%d')

            df_['model'] = model
            df_['month'] = month

            if df is None:
                df = df_
            else:
                df = df.append(df_)

    plot_error_vs_datetime(df)
